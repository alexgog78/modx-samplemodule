<?php

$prefix = 'setting_samplemodule_';

$_lang[$prefix . 'file_source'] = 'Источник файлов по умолчанию';
$_lang[$prefix . 'file_source_desc'] = 'Источник файлов для модуля по умолчанию.';
