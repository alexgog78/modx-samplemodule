<?php

require_once(dirname(__DIR__) . '/samplecollection.class.php');

class sampleCollection_mysql extends sampleCollection
{
}
