<?php

$prefix = 'samplemodule_collection_';

$_lang[$prefix . 'list'] = 'Collections';
$_lang[$prefix . 'list_management'] = 'Manage your collections here. You can change them by double-clicking on the required field or by right-clicking on the required row.';
$_lang[$prefix . 'creating'] = 'Creating collection';
$_lang[$prefix . 'editing'] = 'Updating collection';
$_lang[$prefix . 'data'] = 'Data';
$_lang[$prefix . 'optionone'] = 'Option 1';
$_lang[$prefix . 'optiontwo'] = 'Option 2';
$_lang[$prefix . 'content'] = 'Content';
$_lang[$prefix . 'richtext'] = 'Code (RichText)';
$_lang[$prefix . 'code'] = 'Code (HTML)';
$_lang[$prefix . 'tags'] = 'Tags';
$_lang[$prefix . 'items'] = 'Items';
$_lang[$prefix . 'categories'] = 'Categories';
