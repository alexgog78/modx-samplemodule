<?php

$prefix = 'samplemodule_item_';

$_lang[$prefix . 'list'] = 'Items';
$_lang[$prefix . 'list_management'] = 'Manage your items here. You can change them by double-clicking on the required field or by right-clicking on the required row.';
$_lang[$prefix . 'image'] = 'Image';
$_lang[$prefix . 'collection'] = 'Collection';
$_lang[$prefix . 'data'] = 'Data';
