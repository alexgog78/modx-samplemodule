<?php

require_once(dirname(__DIR__) . '/samplecollectioncategory.class.php');

class sampleCollectionCategory_mysql extends sampleCollectionCategory
{
}
