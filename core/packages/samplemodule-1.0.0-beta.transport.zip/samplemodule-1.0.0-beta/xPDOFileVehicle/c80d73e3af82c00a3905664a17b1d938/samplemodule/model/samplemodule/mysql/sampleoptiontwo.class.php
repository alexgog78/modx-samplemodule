<?php

require_once(dirname(__DIR__) . '/sampleoptiontwo.class.php');

class sampleOptionTwo_mysql extends sampleOptionTwo
{
}
