<?php

require_once(dirname(__DIR__) . '/samplecategory.class.php');

class sampleCategory_mysql extends sampleCategory
{
}
