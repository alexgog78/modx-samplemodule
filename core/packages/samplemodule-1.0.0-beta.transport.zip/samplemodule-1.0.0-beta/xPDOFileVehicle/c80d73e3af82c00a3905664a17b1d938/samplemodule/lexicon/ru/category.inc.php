<?php

$prefix = 'samplemodule_category_';
