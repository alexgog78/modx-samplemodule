<?php

$prefix = 'samplemodule_collection_';

$_lang[$prefix . 'list'] = 'Коллекции';
$_lang[$prefix . 'list_management'] = 'Управляйте вашими коллекциями здесь. Вы можете изменять их двойным щелчком по необходимому полю или щелчком правой кнопки мыши по необходимому ряду.';
$_lang[$prefix . 'creating'] = 'Создание коллекции';
$_lang[$prefix . 'editing'] = 'Редактирование коллекции';
$_lang[$prefix . 'data'] = 'Данные';
$_lang[$prefix . 'optionone'] = 'Опция 1';
$_lang[$prefix . 'optiontwo'] = 'Опция 2';
$_lang[$prefix . 'content'] = 'Содержимое';
$_lang[$prefix . 'richtext'] = 'Код (RichText)';
$_lang[$prefix . 'code'] = 'Код (HTML)';
$_lang[$prefix . 'tags'] = 'Теги';
$_lang[$prefix . 'items'] = 'Предметы';
$_lang[$prefix . 'categories'] = 'Категории';
