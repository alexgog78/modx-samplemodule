'use strict';

Ext.apply(sampleModule.function, {

});
