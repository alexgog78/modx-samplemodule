'use strict';

Ext.apply(sampleModule.renderer, {

});
