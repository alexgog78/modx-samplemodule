<?php

$xpdo_meta_map = [
    'abstractSimpleObject' => [
        0 => 'sampleCollection',
        1 => 'sampleItem',
        2 => 'sampleCategory',
        3 => 'sampleOptionOne',
        4 => 'sampleOptionTwo',
    ],
    'abstractObject' => [
        0 => 'sampleCollectionCategory',
    ],
];
