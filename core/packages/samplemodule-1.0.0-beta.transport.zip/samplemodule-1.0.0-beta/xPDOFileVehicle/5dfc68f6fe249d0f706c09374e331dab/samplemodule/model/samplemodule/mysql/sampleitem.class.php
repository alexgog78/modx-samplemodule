<?php

require_once(dirname(__DIR__) . '/sampleitem.class.php');

class sampleItem_mysql extends sampleItem
{
}
