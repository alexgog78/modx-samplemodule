<?php

require_once(dirname(__DIR__) . '/sampleoptionone.class.php');

class sampleOptionOne_mysql extends sampleOptionOne
{
}
