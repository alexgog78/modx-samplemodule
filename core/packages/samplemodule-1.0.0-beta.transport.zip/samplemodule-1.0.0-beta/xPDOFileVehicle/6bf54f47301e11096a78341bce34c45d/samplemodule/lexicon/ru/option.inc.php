<?php

$prefix = 'samplemodule_option_';
