<?php

$prefix = 'samplemodule_item_';

$_lang[$prefix . 'list'] = 'Предметы';
$_lang[$prefix . 'list_management'] = 'Управляйте вашими предметами здесь. Вы можете изменять их двойным щелчком по необходимому полю или щелчком правой кнопки мыши по необходимому ряду.';
$_lang[$prefix . 'image'] = 'Изображение';
$_lang[$prefix . 'collection'] = 'Коллекция';
$_lang[$prefix . 'data'] = 'Данные';
