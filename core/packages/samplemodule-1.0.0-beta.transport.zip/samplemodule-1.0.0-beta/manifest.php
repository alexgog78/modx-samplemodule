<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for sampleModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
sampleModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'sampleModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c84319858502b0d1ba8aba1465ddbdd1',
      'native_key' => 'samplemodule',
      'filename' => 'modNamespace/7b5535d5435bc896ac45f82c84ba7241.vehicle',
      'namespace' => 'samplemodule',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '940d6f952359c4da9b4e0b0961f230dc',
      'native_key' => '940d6f952359c4da9b4e0b0961f230dc',
      'filename' => 'xPDOFileVehicle/eea7be60b40cc8027a39ef77e32423e5.vehicle',
      'namespace' => 'samplemodule',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5a23705b5267791ec2a7368266fd0fa1',
      'native_key' => '5a23705b5267791ec2a7368266fd0fa1',
      'filename' => 'xPDOFileVehicle/126a4e4dc86535c58ff59a14073ebbed.vehicle',
      'namespace' => 'samplemodule',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ce1cc80122486640024a58edf29cba23',
      'native_key' => 'ce1cc80122486640024a58edf29cba23',
      'filename' => 'xPDOFileVehicle/1c3b674413d304ff8fab9d3240483be8.vehicle',
      'namespace' => 'samplemodule',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87c215f629d7a48fa8e8d18b599339e4',
      'native_key' => 'samplemodule_file_source',
      'filename' => 'modSystemSetting/ca5f81c3fde04995b4eb86e2433c04b7.vehicle',
      'namespace' => 'samplemodule',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '793a8f2e44b35cd162ac0f7771557fe9',
      'native_key' => 'samplemodule',
      'filename' => 'modMenu/611775b4c4139ee1ffd6ab6e9353e2d2.vehicle',
      'namespace' => 'samplemodule',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5331633c30ec0e3fbe6aa699edbcd880',
      'native_key' => 'samplemodule_collections',
      'filename' => 'modMenu/19830193ef12c937073016a05ea936a9.vehicle',
      'namespace' => 'samplemodule',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '30a2dd7dcf6f428601521634c02c4de9',
      'native_key' => 'samplemodule_items',
      'filename' => 'modMenu/7e3c2def61008596b85bea0d5d073f96.vehicle',
      'namespace' => 'samplemodule',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7a23209f6c4354e93e1c234291f82aaa',
      'native_key' => 'samplemodule_settings',
      'filename' => 'modMenu/fa5e50e72ca041d6d7fa3d9ce9ad8276.vehicle',
      'namespace' => 'samplemodule',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '973b5911bb6d6a10bbfa209856b95431',
      'native_key' => NULL,
      'filename' => 'modMediaSource/fecdbe0c2d4bdbac1dfaa809d9048f83.vehicle',
      'namespace' => 'samplemodule',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '0848c19ac9ce007571bcf5a471e0d658',
      'native_key' => '0848c19ac9ce007571bcf5a471e0d658',
      'filename' => 'xPDOScriptVehicle/0579972fa2fc740b69aa3bf956139bcb.vehicle',
      'namespace' => 'samplemodule',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'cf8ac2bdf168af2a6dbd312ebb2886c1',
      'native_key' => 'cf8ac2bdf168af2a6dbd312ebb2886c1',
      'filename' => 'xPDOScriptVehicle/659205e278822ed4bc6ebd1c062c068c.vehicle',
      'namespace' => 'samplemodule',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a69b5c760b1059deb6034880cab79475',
      'native_key' => 'a69b5c760b1059deb6034880cab79475',
      'filename' => 'xPDOScriptVehicle/a9c1bd87ac93757856e3827038dd32d0.vehicle',
      'namespace' => 'samplemodule',
    ),
  ),
);