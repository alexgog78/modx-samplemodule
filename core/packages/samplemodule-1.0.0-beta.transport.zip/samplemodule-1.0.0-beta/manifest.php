<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for sampleModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
sampleModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'sampleModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'abstractModule' => '>=1.1.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '723aab5d2f24c4ef9759e0c6837d6bc9',
      'native_key' => 'samplemodule',
      'filename' => 'modNamespace/37db954fee33ea706dc3ff4294a639cd.vehicle',
      'namespace' => 'samplemodule',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a062c4ee05cbb994c6a9aa0677648b6f',
      'native_key' => 'a062c4ee05cbb994c6a9aa0677648b6f',
      'filename' => 'xPDOFileVehicle/bd90e4ded85bba204bc058634cede108.vehicle',
      'namespace' => 'samplemodule',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '60f9bf18324ae1701d61b933d9432b8d',
      'native_key' => '60f9bf18324ae1701d61b933d9432b8d',
      'filename' => 'xPDOFileVehicle/46479164d99ab284cef3791ecf14b284.vehicle',
      'namespace' => 'samplemodule',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'dbf3f4ae7dca3f7762ae7273bc7f6e0c',
      'native_key' => 'dbf3f4ae7dca3f7762ae7273bc7f6e0c',
      'filename' => 'xPDOFileVehicle/fd5c87e50a0904ed8942077ff295a3ce.vehicle',
      'namespace' => 'samplemodule',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb2356cb1af1a2c918cf9fafa6cbdb82',
      'native_key' => 'samplemodule_file_source',
      'filename' => 'modSystemSetting/d9a1b1e74037cde27141aeb15c50cedd.vehicle',
      'namespace' => 'samplemodule',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bc3d8c8e064d4d01730eb1969868edad',
      'native_key' => 'samplemodule',
      'filename' => 'modMenu/f3711cdb97dc43b2bc9f8111c21e6901.vehicle',
      'namespace' => 'samplemodule',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9ae4aa5cca7f1a34ce328bde8520e597',
      'native_key' => 'samplemodule_collections',
      'filename' => 'modMenu/0aff3abcba339d314e80f2ed2e2b7468.vehicle',
      'namespace' => 'samplemodule',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8f320e93202e22e59c34c70ec313dcf8',
      'native_key' => 'samplemodule_items',
      'filename' => 'modMenu/925039291e51129b21cddfe1d9bf9897.vehicle',
      'namespace' => 'samplemodule',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e1faff9f734b43ce74ba434646a11f10',
      'native_key' => 'samplemodule_settings',
      'filename' => 'modMenu/5acd45e3dc9d31e8f696dcd673814074.vehicle',
      'namespace' => 'samplemodule',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '144225d1a90149ff09cfd0e1bcde83c9',
      'native_key' => NULL,
      'filename' => 'modMediaSource/6c565348bab958ac4305b373e76da8f3.vehicle',
      'namespace' => 'samplemodule',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '003e41eb12e775825cd68e5e56b9d66f',
      'native_key' => '003e41eb12e775825cd68e5e56b9d66f',
      'filename' => 'xPDOScriptVehicle/bf6793837691cb2ac39be9862b166734.vehicle',
      'namespace' => 'samplemodule',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd1206eca160e2a92ba0d7277e998b177',
      'native_key' => 'd1206eca160e2a92ba0d7277e998b177',
      'filename' => 'xPDOScriptVehicle/fea46a1f76a071d87422334ff4e1a43a.vehicle',
      'namespace' => 'samplemodule',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e6ff1cdbb7dab444894a6e302f720604',
      'native_key' => 'e6ff1cdbb7dab444894a6e302f720604',
      'filename' => 'xPDOScriptVehicle/0932a1833330d4a2325a9ed0e6e8c4ce.vehicle',
      'namespace' => 'samplemodule',
    ),
  ),
);