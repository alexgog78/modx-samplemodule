<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for sampleModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
sampleModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'sampleModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'abstractModule' => '>=1.1.0',
    ),
    'copy_exclude_patterns' => 
    array (
      0 => '#test#i',
      1 => '#^__#',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6609f02fb2b451e51ab953562753be28',
      'native_key' => 'samplemodule',
      'filename' => 'modNamespace/c53ddb0097696c6007237476aef66b3a.vehicle',
      'namespace' => 'samplemodule',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0df96955e38e3f258a94f1d77fa86cd9',
      'native_key' => '0df96955e38e3f258a94f1d77fa86cd9',
      'filename' => 'xPDOFileVehicle/c80d73e3af82c00a3905664a17b1d938.vehicle',
      'namespace' => 'samplemodule',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '94cbae8fadbff06171f7e4e37df465a9',
      'native_key' => '94cbae8fadbff06171f7e4e37df465a9',
      'filename' => 'xPDOFileVehicle/acaa565c466d8c936bbbb662fba18f6b.vehicle',
      'namespace' => 'samplemodule',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '42ee2bef9f5913190aba6d5657f0e95a',
      'native_key' => '42ee2bef9f5913190aba6d5657f0e95a',
      'filename' => 'xPDOFileVehicle/6f9b9433ebcbfa1e49f9009e0116be7f.vehicle',
      'namespace' => 'samplemodule',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75ae702bc8105f7bc0cc3c42f7a206e3',
      'native_key' => 'samplemodule_file_source',
      'filename' => 'modSystemSetting/e1993ae1c001ffba349d65babea64bee.vehicle',
      'namespace' => 'samplemodule',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4e5d0ee300493f25cf333c55ccb317e5',
      'native_key' => 'samplemodule',
      'filename' => 'modMenu/8e3063afbc73c86e4df52db470c262f5.vehicle',
      'namespace' => 'samplemodule',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6060073c8b043f39557e271f389b227e',
      'native_key' => 'samplemodule_collections',
      'filename' => 'modMenu/97127507948c41c2dcfd6e6b5a68e685.vehicle',
      'namespace' => 'samplemodule',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0dd54d871ae665e7a7aa25a2e47f48d7',
      'native_key' => 'samplemodule_items',
      'filename' => 'modMenu/921e30b4c0936251d51e5352a9ef621d.vehicle',
      'namespace' => 'samplemodule',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4bcbd395449b1287e18742c0429822a5',
      'native_key' => 'samplemodule_settings',
      'filename' => 'modMenu/f95521139a4eb74ff3346bdf205c697d.vehicle',
      'namespace' => 'samplemodule',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '917a9aef6d8f0a98aa23dbb479a97c32',
      'native_key' => NULL,
      'filename' => 'modMediaSource/d3b8cf1662a4d33e7b2b247d361fa91a.vehicle',
      'namespace' => 'samplemodule',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '14da0347db8e79f58a73ed83cd1ae30d',
      'native_key' => '14da0347db8e79f58a73ed83cd1ae30d',
      'filename' => 'xPDOScriptVehicle/bc4b32119c69665d84062e70b1248e56.vehicle',
      'namespace' => 'samplemodule',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '3b0c6254699121d49df349e5ac8e9e2f',
      'native_key' => '3b0c6254699121d49df349e5ac8e9e2f',
      'filename' => 'xPDOScriptVehicle/81fb6d9ceb1a792eff5a632ee7d0e4b7.vehicle',
      'namespace' => 'samplemodule',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6b36b4bd93e8193d6d137a902d9504f8',
      'native_key' => '6b36b4bd93e8193d6d137a902d9504f8',
      'filename' => 'xPDOScriptVehicle/5957f773bd371d443e7440a3138095b9.vehicle',
      'namespace' => 'samplemodule',
    ),
  ),
);