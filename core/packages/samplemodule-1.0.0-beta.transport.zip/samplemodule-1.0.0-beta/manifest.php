<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for sampleModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
sampleModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'sampleModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'abstractModule' => '>=1.1.0',
    ),
    'copy_exclude_patterns' => 
    array (
      0 => '#test#i',
      1 => '#^__#',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b9a491f8c1e53d92538f26738b6cc3d4',
      'native_key' => 'samplemodule',
      'filename' => 'modNamespace/39d3b70343f219700341a9d308c51e87.vehicle',
      'namespace' => 'samplemodule',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'ee7360d8355b2c784c8a29ea3860d792',
      'native_key' => 'ee7360d8355b2c784c8a29ea3860d792',
      'filename' => 'xPDOFileVehicle/5dfc68f6fe249d0f706c09374e331dab.vehicle',
      'namespace' => 'samplemodule',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b1e3ac88578a83598e521226e6092717',
      'native_key' => 'b1e3ac88578a83598e521226e6092717',
      'filename' => 'xPDOFileVehicle/db45a3d7147319b9d7c0afaecd0995b6.vehicle',
      'namespace' => 'samplemodule',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'aa97c5b2cb7ce442a2b611e5ac4ae56e',
      'native_key' => 'aa97c5b2cb7ce442a2b611e5ac4ae56e',
      'filename' => 'xPDOFileVehicle/2c2005ef2668afc6c1c7bd7d7e9ce88f.vehicle',
      'namespace' => 'samplemodule',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de551509f3d78a539d1f2f3a21438f11',
      'native_key' => 'samplemodule_file_source',
      'filename' => 'modSystemSetting/8de33ead12c78c3f333e1426bcf8fb85.vehicle',
      'namespace' => 'samplemodule',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'def24a2169d1904e00ceb2b9c87a878b',
      'native_key' => 'samplemodule',
      'filename' => 'modMenu/58f413582c5e10d3ff7f8d0db4bbc9d7.vehicle',
      'namespace' => 'samplemodule',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '425868473032f3b13182353afc3f5fd6',
      'native_key' => 'samplemodule_collections',
      'filename' => 'modMenu/10c44e30019ffa4bb00204b3170cc375.vehicle',
      'namespace' => 'samplemodule',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '42534bf7015b8d4a4287eb2353f7a394',
      'native_key' => 'samplemodule_items',
      'filename' => 'modMenu/64bb2a01f550ada57e79c1d1994e876e.vehicle',
      'namespace' => 'samplemodule',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c405b2f1a9ce268000d16e607c822cf2',
      'native_key' => 'samplemodule_settings',
      'filename' => 'modMenu/beecbc0a878142d8b220e012c74a793a.vehicle',
      'namespace' => 'samplemodule',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '427a284ac85c5540cbf425dd15f168a7',
      'native_key' => NULL,
      'filename' => 'modMediaSource/c4436ee45c5daf1ec76553885ee7f4e6.vehicle',
      'namespace' => 'samplemodule',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '13b9322d31362c34bea391155046bad6',
      'native_key' => '13b9322d31362c34bea391155046bad6',
      'filename' => 'xPDOScriptVehicle/7104363db96498dfe225871237a482e2.vehicle',
      'namespace' => 'samplemodule',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '672c1118208b160a36fdcdbf498e4e23',
      'native_key' => '672c1118208b160a36fdcdbf498e4e23',
      'filename' => 'xPDOScriptVehicle/5d979427419d84495cb5a2985575513f.vehicle',
      'namespace' => 'samplemodule',
    ),
  ),
);