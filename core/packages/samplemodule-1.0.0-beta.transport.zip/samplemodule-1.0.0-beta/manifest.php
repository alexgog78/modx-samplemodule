<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for sampleModule.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
sampleModule
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'sampleModule
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
    'requires' => 
    array (
      'php' => '>=7.0',
      'modx' => '>=2.4',
      'abstractModule' => '>=1.1.0',
    ),
    'copy_exclude_patterns' => 
    array (
      0 => '#test#i',
      1 => '#^__#',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4e6e2e2d5afa069e78a5b512bc0671e6',
      'native_key' => 'samplemodule',
      'filename' => 'modNamespace/515ccb20379829f63ccce401e5d50fa4.vehicle',
      'namespace' => 'samplemodule',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '239b6da2f2e7ed0570e6c94615a5a3d8',
      'native_key' => '239b6da2f2e7ed0570e6c94615a5a3d8',
      'filename' => 'xPDOFileVehicle/6bf54f47301e11096a78341bce34c45d.vehicle',
      'namespace' => 'samplemodule',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'aa9cc614b4c54ffd14767de892a0f032',
      'native_key' => 'aa9cc614b4c54ffd14767de892a0f032',
      'filename' => 'xPDOFileVehicle/f0f3ba63ec73385743fba330dd050d56.vehicle',
      'namespace' => 'samplemodule',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '75b983d872f18709559ba4e08333226a',
      'native_key' => '75b983d872f18709559ba4e08333226a',
      'filename' => 'xPDOFileVehicle/8ea926ce1c44ed45ca76bcaae4752343.vehicle',
      'namespace' => 'samplemodule',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08778f9d874b6ee49b8c28e7b0cc94fa',
      'native_key' => 'samplemodule_file_source',
      'filename' => 'modSystemSetting/b3732c76673057445a8dc289c931fcd2.vehicle',
      'namespace' => 'samplemodule',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '7eb31129b709e545bb1f52be2bbc0ff2',
      'native_key' => 'samplemodule',
      'filename' => 'modMenu/b0f618d5b190970f1332cc3600ec29ce.vehicle',
      'namespace' => 'samplemodule',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3ae3170a97ec038f26f6dca4a215f15b',
      'native_key' => 'samplemodule_collections',
      'filename' => 'modMenu/d0a1468a613c84f1e93afbd34cfacd43.vehicle',
      'namespace' => 'samplemodule',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '45553d24956c3b3bf0b5f06b453732c1',
      'native_key' => 'samplemodule_items',
      'filename' => 'modMenu/fc7464f0a83dad7e2c50be73d5ceef3c.vehicle',
      'namespace' => 'samplemodule',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '14a82568ef8fb98f94152f5ea7d43433',
      'native_key' => 'samplemodule_settings',
      'filename' => 'modMenu/d2637dd94528bc2edde40e838ca1f6a4.vehicle',
      'namespace' => 'samplemodule',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'f6844ed809fcf2e5429b161e388be96b',
      'native_key' => NULL,
      'filename' => 'modMediaSource/3a2b815523914b387fafdf20fba7a572.vehicle',
      'namespace' => 'samplemodule',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '2d0fc1cf41bce485f3f28daf1adb8323',
      'native_key' => '2d0fc1cf41bce485f3f28daf1adb8323',
      'filename' => 'xPDOScriptVehicle/494229281309d420310b9ac51b377d12.vehicle',
      'namespace' => 'samplemodule',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9aea882e95653c7edb1aad96b668447f',
      'native_key' => '9aea882e95653c7edb1aad96b668447f',
      'filename' => 'xPDOScriptVehicle/a0f4b09b70707dd7be0dc1288a4ad692.vehicle',
      'namespace' => 'samplemodule',
    ),
  ),
);